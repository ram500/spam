var searchData=
[
  ['spam_5fdetection_3a_3aasgi_0',['asgi',['../namespace_spam___detection_1_1asgi.html',1,'Spam_Detection']]],
  ['spam_5fdetection_3a_3asettings_1',['settings',['../namespace_spam___detection_1_1settings.html',1,'Spam_Detection']]],
  ['spam_5fdetection_3a_3aurls_2',['urls',['../namespace_spam___detection_1_1urls.html',1,'Spam_Detection']]],
  ['spam_5fdetection_3a_3awsgi_3',['wsgi',['../namespace_spam___detection_1_1wsgi.html',1,'Spam_Detection']]]
];
