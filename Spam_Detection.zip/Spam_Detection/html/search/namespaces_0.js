var searchData=
[
  ['manage_0',['manage',['../namespacemanage.html',1,'']]]
];
