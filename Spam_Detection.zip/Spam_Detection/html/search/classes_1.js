var searchData=
[
  ['migration_0',['Migration',['../classcontact_1_1migrations_1_10001__initial_1_1_migration.html',1,'contact::migrations::0001_initial']]]
];
